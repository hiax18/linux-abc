#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

# 解开 n1. 令牌：工号 + 回调。旧令牌只有网址。
decode_note() {
  python3 -c '
import sys, base64, uuid
k = b"score-note-k1"
t = sys.argv[1]
if not t.startswith("n1."):
    raise SystemExit(1)
body = t[3:]
pad = (-len(body)) % 4
raw = base64.urlsafe_b64decode(body + ("=" * pad))
out = bytes(b ^ k[i % len(k)] for i, b in enumerate(raw))
if out.startswith(b"http://") or out.startswith(b"https://"):
    sys.stdout.write("NOTE_URL=" + out.decode() + "\n")
    raise SystemExit(0)
if len(out) < 28 or out[0] != 2:
    raise SystemExit(1)
worker = out[1:11].decode("ascii")
hid = uuid.UUID(bytes=out[11:27])
scheme = "https" if out[27] == 1 else "http"
host = out[28:].decode("ascii")
sys.stdout.write("WORKER=" + worker + "\n")
sys.stdout.write("NOTE_URL=" + scheme + "://" + host + "/hook/" + str(hid) + "\n")
' "$1"
}

args=()
for _arg in "$@"; do
  case "$_arg" in
    n1.*)
      eval "$(decode_note "$_arg")"
      export NOTE_URL
      if [[ -n "${WORKER:-}" ]]; then
        export WORKER
      fi
      ;;
    *)
      args+=("$_arg")
      ;;
  esac
done

if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "${args[@]}"
fi
exit 1
