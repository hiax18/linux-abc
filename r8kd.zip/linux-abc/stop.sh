#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/stop.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/stop.sh 2>/dev/null || true
fi
if [[ -x app/stop.sh ]]; then
  exec bash app/stop.sh
fi
exit 0
