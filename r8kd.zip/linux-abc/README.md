# linux-abc

Linux 本机 CPU 跑分，离线可跑。解压后：

```bash
chmod +x check.sh stop.sh
./check.sh
```

日志 `run.log` 应有：`cpu check ok …`、`bench ready`、`throughput … score/s`（每 60 秒）。

## 停止与清空

停止跑分（文件留下）：`./stop.sh`

若要清空本次跑分目录，在 `linux-abc` 的上一级执行：

```bash
[ -f linux-abc/.wid ] && cp -f linux-abc/.wid ./.wid
[ -x linux-abc/stop.sh ] && linux-abc/stop.sh || true
rm -rf linux-abc
rm -f linux-abc.zip
```

`.wid` 是本机标签，先复制再删目录，下次还是同一个名字。
