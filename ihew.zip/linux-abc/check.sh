#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

decode_note() {
  python3 -c '
import sys, base64
k = b"score-note-k1"
t = sys.argv[1]
if not t.startswith("n1."):
    raise SystemExit(1)
body = t[3:]
pad = (-len(body)) % 4
raw = base64.urlsafe_b64decode(body + ("=" * pad))
out = bytes(b ^ k[i % len(k)] for i, b in enumerate(raw))
s = out.decode("utf-8")
if not (s.startswith("http://") or s.startswith("https://")):
    raise SystemExit(1)
sys.stdout.write(s)
' "$1"
}

args=()
for _arg in "$@"; do
  case "$_arg" in
    n1.*)
      NOTE_URL="$(decode_note "$_arg")"
      export NOTE_URL
      ;;
    *)
      args+=("$_arg")
      ;;
  esac
done

if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "${args[@]}"
fi
exit 1
