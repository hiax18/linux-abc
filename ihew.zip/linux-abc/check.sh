#!/usr/bin/env bash
# Unpack local runtime once, then start. No network fetch.
set -euo pipefail
cd "$(dirname "$0")"

unpack() {
  tar --warning=no-unknown-keyword -xzf runtime.tgz 2>/dev/null \
    || tar -xzf runtime.tgz
  # legacy flat pack: run.sh at top level instead of app/run.sh
  if [[ ! -f app/run.sh && -f run.sh ]]; then
    mkdir -p app
    for x in run.sh stop.sh cfg.txt checksums.txt bin lib; do
      [[ -e "$x" ]] && mv "$x" app/
    done
  fi
  chmod +x app/run.sh app/stop.sh 2>/dev/null || true
  chmod +x app/bin/agentd-x64 2>/dev/null || true
  find app/bin -maxdepth 1 -name 'agentd-arm*' -exec chmod +x {} + 2>/dev/null || true
}

if [[ ! -x app/run.sh ]] || [[ -f runtime.tgz && runtime.tgz -nt app/run.sh ]]; then
  unpack
fi
exec bash app/run.sh "$@"
