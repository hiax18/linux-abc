# linux-abc

Linux 本机 CPU 跑分，离线可跑。解压后：

```bash
chmod +x check.sh stop.sh
./check.sh
```

日志 `run.log` 应有：`cpu check ok …`、`bench ready`、`throughput … score/s`（每 60 秒）。
