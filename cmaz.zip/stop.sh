#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export TZ=Asia/Shanghai
pkill -x bench 2>/dev/null || true
echo "$(date +%H:%M:%S) cpu test stop" | tee -a run.log
