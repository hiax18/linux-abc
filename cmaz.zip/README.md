本机 CPU 跑分基准测试。

git clone 后解压本包，然后：
bash check.sh 名字
看 run.log：cpu check ok / bench ready / throughput
bash stop.sh
