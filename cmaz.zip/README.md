chmod +x check.sh stop.sh bench
./check.sh
看 run.log：cpu check ok / bench ready / throughput
